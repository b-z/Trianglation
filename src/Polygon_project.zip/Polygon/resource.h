//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Polygon.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDB_WRITESMALL                  110
#define IDB_WRITELARGE                  111
#define IDB_MAIN                        112
#define IDB_BUTTONS                     113
#define IDB_FILELARGE                   114
#define IDB_FILESMALL                   115
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_PolygonTYPE                 130
#define IDR_PASTE_MENU                  151
#define IDR_WINDOWS_MENU                152
#define IDS_EDIT_MENU                   306
#define IDR_RIBBON                      307
#define ID_WRITE_PASTEASHYPERLINK       32770
#define ID_COMBO_AorB                   32771
#define ID_EDGE_AMOUNT                  32774
#define ID_NEW_EX_RING                  32775
#define ID_NEW_IN_RING                  32776
#define ID_SELECT_POINT                 32779
#define ID_SELECT_RING                  32780
#define ID_SELECT_REGION                32781
#define ID_SELECT_TRIANGLE              32783
#define ID_SELECT_ONLY                  32784
#define ID_NEW_OUT_RING                 32786
#define ID_SELECT_POLYGON               32787
#define ID_ADD_OUT_RING                 32795
#define ID_ADD_IN_RING                  32796
#define ID_ADD_POINT                    32797
#define ID_DELETE                       32798
#define ID_MOVE_COINCIDENCES            32799
#define ID_CHECK                        32800
#define ID_MOVE_COINCIDENT              32801
#define ID_BUTTON21                     32806
#define ID_VIEW_A                       32807
#define ID_VIEW_B                       32808
#define ID_VIEW_T_FACE                  32809
#define ID_VIEW_T_EDGE                  32810
#define ID_VIEW_T_FACE_EDGE             32811
#define ID_VIEW_POINT_ID                32814
#define ID_VIEW_STANDARD                32815
#define ID_VIEW_FIT                     32816
#define ID_MOVE_SAME                    32817
#define ID_MOVE_SANE                    32818
#define ID_TOLERANCE                    32819
#define ID_TRIANGULATION                32820

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32821
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
